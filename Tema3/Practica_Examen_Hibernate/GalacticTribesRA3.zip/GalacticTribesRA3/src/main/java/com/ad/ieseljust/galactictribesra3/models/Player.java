/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ad.ieseljust.galactictribesra3.models;

import java.io.Serializable;

/**
 *
 * @author jasb
 */

public class Player implements Serializable{
    
    static final long serialVersionUID = 17L;
    
    
}
